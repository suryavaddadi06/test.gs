package de.komoot.photon.searcher;

public enum TagFilterKind {
    INCLUDE,
    EXCLUDE,
    EXCLUDE_VALUE;
}
